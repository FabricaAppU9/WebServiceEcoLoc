<?php

class EndPoint 
{ 
  private $endPoint = 'http://janjrs.000webhostapp.com/';      
  public function getEndPoint() 
  { 
    return $this->endPoint; 
  } 
}