<html lang="pt-br">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    </head>
    <body> 
        <p style='width: 100%; text-align: center'>DOCUMENTAÇÃO DO WEB SERVICE PARA APP ECOLOC</p>
        <p style='width: 100%; text-align: center'> 
                Este WS é apenas para testes academicos para troca de informação entre DataBase e smartfone,
                contem funções para cadastrar, atualizar, deletar  e consultar registros em um db.
        </p>

        <ul>
                <li>
                    <p>Exemplo de todos os metódos referentes há usuários</p>
                    <ul>
                        <li><a href='Create/usuarioDTOCreate.php'>Criar Usuários</a></li>
                        <li><a href='Read/usuarioDTORead.php'>Seleção de Usuários</a></li>
                        <li><a href='Read/usuarioDto.php'>Seleção de Usuário</a></li>
                        <li><a href='Update/usuarioDTOUpdate.php'>Atualizar Usuário</a></li>
                        <li><a href='Delete/usuarioDTODelete.php'>Deletar Usuário</a></li>
                        <li><a href='Read/usuarioDTOReadLogar.php'>Logar</a></li>
                    </ul>
                </li>
                <li>
                    <p>Exemplo de todos os metódos referentes há marcação de pontos no mapa</p>
                    <ul>
                        <li><a href='Create/pontosCreate.php'>Criar Ponto</a></li>
                        <li><a href='Read/pontosRead.php'>Selecionar Ponto</a></li>
                        <li><a href='Update/pontosUpdate.php'>Atualizar Ponto</a></li>
                        <li><a href='Delete/pontosDelete.php'>Deletar Ponto</a></li>
                    </ul>
                </li>
            <li>
                <p>Exemplo de todos os metódos referentes há ranking</p>
                <ul>
                    <li><a href='Create/rankingCreate.php'>Criar Ranking</a></li>
                    <li><a href='Read/rankingRead.php'>Seleção dos Ranking</a></li>
                    <li><a href='Update/rankingUpdate.php'>Atualizar Ranking</a></li>
                    <li><a href='Delete/rankingDelete.php'>Deletar Ranking</a></li>
                </ul>
            </li>
            <li>
                <p>Exemplo de todos os metódos referentes há tipos de materias</p>
                <ul>                    
                    <li><a href='Read/tipoMaterialRead.php'>Seleção dos Ranking</a></li>                    
                </ul>
            </li>
            

        </ul>    
        <p>CRIADO POR JANAILSON ROCHA DE SOUSA</p>
    </body>
</html>